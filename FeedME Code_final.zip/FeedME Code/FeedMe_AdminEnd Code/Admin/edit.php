<?php
//This EDIT page replaces the User's old details in the database with new ones.
include("DBConnection.class.php");
$dbConn = new DBConnection();
$UserID=$_POST['UserID'];
$Email=$_POST['Email']; 
$Nickname=$_POST['Nickname'];
$Phone=$_POST['Phone'];
$Address=$_POST['Address'];

$sql1 = "select * from Users where UserID={$UserID}";
$result1 = $dbConn->query($sql1);
$row1 = $result1 -> fetch_assoc();


//Sql command to replace the old details with new ones.
$sql = "UPDATE Users SET Email='{$Email}', Nickname = '{$Nickname}', Phone = '{$Phone}', 
	Address = '{$Address}' WHERE UserID={$UserID}";

if($row1){
	$result = $dbConn->query($sql);
	echo "<script type='text/javascript'>alert('Update successfully.');window.location='index.php';</script>";
}
else{
	echo "<script type='text/javascript'>alert('User does not exist.');window.location=history.go(-1)</script>";
}

?>

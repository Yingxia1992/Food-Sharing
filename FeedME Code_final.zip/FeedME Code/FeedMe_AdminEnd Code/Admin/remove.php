<?php
// sql command to remove a user from the 'Users' table in the database.
include("DBConnection.class.php");
$dbConn = new DBConnection();
$UserID=$_POST['UserID'];

$sql1 = "select * from Users where UserID={$UserID}";
$result11 = $dbConn->query($sql1);
$row1 = $result11 -> fetch_assoc();

$sql = "DELETE FROM Users WHERE UserID= {$UserID}";
echo $sql;
if($row1){
	$result = $dbConn->query($sql);
	echo "<script type='text/javascript'>alert('Remove successfully.');window.location='index.php';</script>";
}
else{
	echo "<script type='text/javascript'>alert('User does not exist.');window.location=history.go(-1)</script>";
}
?>
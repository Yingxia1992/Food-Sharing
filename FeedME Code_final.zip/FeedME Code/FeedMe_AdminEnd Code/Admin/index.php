<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"  name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="FeedME.css" rel="stylesheet">

    <title>FeedME</title>
<!--Javascript function to introduce a search filter-->
<script>

  function myFunction()
  {
    var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  //hiding table rows that dont match the query
  for (i = 0; i < tr.length; i++) {
    //Getting the search element's index
    td = tr[i].getElementsByTagName("td")[2];

    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}

</script>
</head>
<body>

<div class="title-page"> <h1 id="font1" >FeedME<input type="button" value="Home" onclick="window.location.href='index.php'"></h1></div>


    <?php
            include("DBConnection.class.php");
    ?>
    <h1> Welcome to the Admin Page</h1>

<div class="form" >
    <form action ="fooddata.php" method="post">
    <div><button><h3>Click here to edit food<h3></button></div>
    </form>
</div>

<p></p>
<h2> EDIT USER</h2>
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="... Search User By Nickname...">
<p><a href="edit.html">Edit</a></p>
<p><a href="remove.html">Remove</a></p>
<p></p>
<form>
  <fieldset>
    <legend><b>User Details</b></legend>
   
<table id="myTable" border='1'>
  
    <tr>
    <th>ID</th>
    <th>Email</th>
    <th>Nickname</th>
    <th>Password</th>
     <th>Phone</th>
      <th>Address</th>
    
</tr>
     <!--Introducing PHP into the code to display the results of the database-->   
<?php
	$dbConn = new DBConnection();
	
     $sql = "SELECT * FROM Users";
		
     $result = $dbConn -> query($sql);
	
   while($row = $result -> fetch_assoc()){
?>
    <tr>
        <td>
      <?php
      echo $row['UserID'];
      ?>
    </td>
    <td>
      <?php
      echo $row['Email'];
      ?>
    </td>
    <td>
      <?php
      echo $row['Nickname'];
      ?>
    </td>
    <td>
      <?php
      echo $row['Password'];
      ?>
    </td>
    <td>
      <?php
      echo $row['Phone'];
      ?>
    </td>
    <td>
      <?php
      echo $row['Address'];
      ?>
    </td>
    
    <?php
}
//$dbConn->close();
?>

</table>
</fieldset>
 </form>


</body>
</html>
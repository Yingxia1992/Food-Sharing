<?php
// sql command to remove a user from the 'Foods' table in the database.
include("DBConnection.class.php");
$dbConn = new DBConnection();
$FoodID=$_POST['FoodID'];

$sql1 = "select * from Foods where FoodID={$FoodID}";
$result11 = $dbConn->query($sql1);
$row1 = $result11 -> fetch_assoc();

$sql = "DELETE FROM Foods WHERE FoodID= {$FoodID}";

if($row1){
	$result = $dbConn->query($sql);
	echo "<script type='text/javascript'>alert('Remove successfully.');window.location='index.php';</script>";
}
else{
	echo "<script type='text/javascript'>alert('Food does not exist.');window.location=history.go(-1)</script>";
}
?>
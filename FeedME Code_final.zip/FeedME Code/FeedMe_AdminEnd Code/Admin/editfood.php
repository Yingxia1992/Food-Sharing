<?php
//This EDIT page replaces the User's old details in the database with new ones.
include("DBConnection.class.php");
$dbConn = new DBConnection();
$FoodID=$_POST['FoodID'];
$FoodName=$_POST['FoodName']; 
$FoodDescription=$_POST['FoodDescription'];
$FoodType=$_POST['FoodType'];
$Quantity=$_POST['Quantity'];
$SharerID=$_POST['SharerID'];
$LocationX=$_POST['LocationX'];
$LocationY=$_POST['LocationY'];

$sql = "select * from Foods where FoodID={$FoodID}";
//Sql command to replace the old details with new ones.
$sql2 = "UPDATE Foods SET FoodName = '{$FoodName}', FoodDescription = '{$FoodDescription}', FoodType = '{$FoodType}' , Quantity = '{$Quantity}', SharerID = '{$SharerID}', LocationX = '{$LocationX}' , LocationY = '{$LocationY}' WHERE FoodID={'$FoodID'}";
$result1 = $dbConn->query($sql);
$row = $result1 -> fetch_assoc();

if($row){
	$result2 = $dbConn->query($sql2);
	echo "<script type='text/javascript'>alert('Update successfully.');window.location='index.php';</script>";
}
else{
	echo "<script type='text/javascript'>alert('Food does not exist.');window.location=history.go(-1)</script>";
}

?>

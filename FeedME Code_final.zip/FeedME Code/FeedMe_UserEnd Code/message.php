<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="background.css" rel="stylesheet">

    <title>FeedME</title>


    <style type="text/css">
        .disabled {
        }
        .disabled optgroup{
            font-size: 12px;
            font-style: normal;
            font-weight: normal;
            font-variant: normal;
            color:#CCCCCC;
            background-color: #F5F5F5;
        }
        .disabled option {
            padding-left:0px;
        }
        .op1{
            font-size: 50px;
            background-color: steelblue;
        }
    </style>

</head>
<body>
<select name="carCos" class="disabled">
    <optgroup label="American"></optgroup>
    <option value="General Motors" class="op1">General Motors</option>
    <option value="Ford">Ford Motor Company</option>
    <option value="Chrysler">DaimlerChrysler</option>
    <optgroup label="Japanese"> </optgroup>
</select>


</body>
</html>
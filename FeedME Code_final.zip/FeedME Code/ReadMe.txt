The code is divided into User-end part and Admin-end part



For Admin-end part it can view, edit and remove both users and foods



For User-end part you can use the user Jenny with password Jenny, Charli with password Charli 
since they already have many sharing food 
or you can also registe your own.

For the code part there are some php files working as controller to update or visit database
such as manageitem2, search funcion etc and use AJAX to call through JavaScript file
and included DBConnection.class file to connect to the database.

All chatting function have included chat.class.php,
NoticeDetail and chatWindo is to operate window 
while send&getMessage and getNoticeDetail&Num working in it.



